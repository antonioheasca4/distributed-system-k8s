<?php
// Only used for dealing with old Joomla 3 extensions (not reinstalled after upgrade to Joomla 3)
